package com.example.vnm;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        ArrayList<String> bundle = getIntent().getExtras().getStringArrayList("list");

        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1,bundle);

        ListView listView = findViewById(R.id.nrMatricolListView);

        listView.setAdapter(adapter);
    }
}