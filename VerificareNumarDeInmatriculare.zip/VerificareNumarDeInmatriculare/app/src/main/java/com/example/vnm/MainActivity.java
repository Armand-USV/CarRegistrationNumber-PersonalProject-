package com.example.vnm;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    EditText nrMatricolEditText;
    Button verifyButton;
    LinkedHashMap<String, Boolean> nrMatricole;
    LinkedHashMap<HashMap<String,Boolean>, ArrayList<String>> dateAsigurare ;
    int nrLetters, nrNumbers, timerCounter, dateExpirareCounter = 0;
    String nrMatString;
    ArrayList<String> nrMatricolList , dateExpirareAsigurare;
    ProgressBar progressBar;
    Handler handler = new Handler();

    public void AlertDialogMessage(int opt) {

        nrMatricolEditText.setText("");
        nrLetters = nrNumbers = 0;

        switch (opt) {
            case 1:
                new AlertDialog.Builder(this)
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .setTitle("Eroare !")
                        .setMessage("Numarul de inmatriculare introdus este gresit! \n" +
                                "Reintroduceti!")
                        .setPositiveButton("Ok", (dialog, which) -> {
                            dialog.cancel();
                        })
                        .show();
                break;

            case 2:
                new AlertDialog.Builder(this)
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .setTitle("Verificare...")
                        .setMessage("Masina cu numarul de inmatriculare " + nrMatString + " are asigurare !")
                        .setPositiveButton("Mai multe detalii", (dialog, which) -> {

                            for ( Map.Entry<HashMap<String,Boolean>,ArrayList<String>> entry : dateAsigurare.entrySet() ) {

                                if ( entry.getKey().containsValue(true) ) {

                                    new AlertDialog.Builder(this)
                                            .setIcon(android.R.drawable.ic_dialog_alert)
                                            .setMessage("Expira la data de " + entry.getValue().get(dateExpirareCounter) )
                                            .setPositiveButton("Ok", (dialog1, which1) -> {
                                                dialog1.cancel();
                                            })
                                            .show();

                                    if ( dateExpirareCounter < dateExpirareAsigurare.size() ) {
                                        dateExpirareCounter++;
                                    } else {
                                        dateExpirareCounter = 0 ;
                                    }
                                    break;
                                }
                            }

                        })
                        .setNegativeButton("Ok", (dialog, which) -> {
                            dialog.cancel();
                        })
                        .show();
                break;

            case 3:
                new AlertDialog.Builder(this)
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .setTitle("Verificare...")
                        .setMessage("Masina cu numarul de inmatriculare " + nrMatString + " nu are asigurare !")
                        .setPositiveButton("Ok", (dialog, which) -> {
                            dialog.cancel();
                        })
                        .show();
                break;

            case 4:
                new AlertDialog.Builder(this)
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .setTitle("Eroare !")
                        .setMessage("Va rugam introduceti numarul de inmatriculare !")
                        .setPositiveButton("Ok", (dialog, which) -> {
                            dialog.cancel();
                        })
                        .show();
                break;

            case 5:
                new AlertDialog.Builder(this)
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .setTitle("Verificare...")
                        .setMessage("Masina cu numarul de inmatriculare " + nrMatString + " nu exista in baza de date !")
                        .setPositiveButton("Ok", (dialog, which) -> {
                            dialog.cancel();
                        })
                        .show();
                break;
        }
    }

    public boolean VerifyAndReturnTheValue() {

        boolean ok = false;

        for (Map.Entry<String, Boolean> entry : nrMatricole.entrySet()) {

            if (nrMatString.equals(entry.getKey())) {
                ok = entry.getValue();
                break;
            }
        }

        return ok;
    }

    public boolean VerifyNrMatIntoHasMap() {

        for (Map.Entry<String, Boolean> entry : nrMatricole.entrySet()) {

            if (nrMatString.equals(entry.getKey())) {
                return true;
            }
        }
        return false;
    }

    public void onVerifyButtonClick(View view) {

        nrMatString = nrMatricolEditText.getText().toString();

        verifyButton.setEnabled(false);
        nrMatricolEditText.setEnabled(false);
        progressBar.setVisibility(View.VISIBLE);

        new Thread(new Runnable() {
            @Override
            public void run() {

                try {
                    Thread.sleep(3000);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                while (timerCounter < 100) {
                    timerCounter++;
                    progressBar.setProgress(timerCounter);
                }

                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        progressBar.setVisibility(View.INVISIBLE);
                        verifyButton.setEnabled(true);
                        nrMatricolEditText.setEnabled(true);
                        RESULT();
                    }
                });
            }
        }).start();
    }

    public void setNrMatricolList() {

        nrMatricolList = new ArrayList<>();

        for (Map.Entry<String, Boolean> entry : nrMatricole.entrySet()) {
            nrMatricolList.add(entry.getKey());
        }
    }

    public void RESULT() {
        if (nrMatString.equals("")) {

            AlertDialogMessage(4);

        } else {

            if (nrMatString.length() != 7) {

                AlertDialogMessage(1);

            } else {

                for (int i = 0; i < 7; i++) {

                    if (Character.isLetter(nrMatString.charAt(i))) {

                        nrLetters++;

                    } else {

                        nrNumbers++;

                    }
                }

                if (nrLetters == 5 && nrNumbers == 2) {

                    if (!VerifyNrMatIntoHasMap()) {

                        AlertDialogMessage(5);

                    } else {

                        if (VerifyAndReturnTheValue()) {

                            AlertDialogMessage(2);

                        } else {

                            AlertDialogMessage(3);

                        }
                    }
                } else {
                    AlertDialogMessage(1);
                }
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.main_menu, menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        super.onOptionsItemSelected(item);

        if (item.getItemId() == R.id.lnm) {
            setNrMatricolList();

            Intent intent = new Intent(this.getApplicationContext(), Main2Activity.class);
            intent.putExtra("list", nrMatricolList);

            startActivity(intent);
            return true;
        }
        return false;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nrMatricolEditText = findViewById(R.id.nrMatricoleditTextTextPersonName);
        verifyButton = findViewById(R.id.verifyButton);
        progressBar = findViewById(R.id.progressBar);

        nrMatricole = new LinkedHashMap<>();
        nrMatricole.put("SV02PRA", true);
        nrMatricole.put("SV19PVA", false);
        nrMatricole.put("SV93GEO", false);
        nrMatricole.put("SV20PND", false);
        nrMatricole.put("SV09LRU", true);
        nrMatricole.put("SV15YAL", false);

        dateExpirareAsigurare = new ArrayList<>();
        dateExpirareAsigurare.add("24/07/2022");
        dateExpirareAsigurare.add("02/04/2025");

        dateAsigurare = new LinkedHashMap<>();
        dateAsigurare.put(nrMatricole , dateExpirareAsigurare);
        dateAsigurare.put(nrMatricole , dateExpirareAsigurare);

    }
}